from flask import Flask,render_template,request

app = Flask(__name__)

@app.route('/')
def home():
    title = "Welcome to conference"
    return render_template('home.html',title=title)

@app.route('/aboutus')
def about_us():
    title = "About Us"
    return render_template('aboutus.html',title=title)

@app.route('/hotels')
def hotels():
    title = "Hotels and Travels"
    return render_template('hotel.html',title=title)

@app.route('/registration')
def registration():
    title = "Registration"
    return render_template('registration.html',title=title)

@app.route('/sponsors')
def sponsors():
    title = "Sponsorships"
    return render_template('sponsors.html',title=title)

@app.route('/general-members')
def general_members():
    title = "General Members"
    return render_template('general_members.html',title=title)

if __name__=='__main__':
    app.run(host="0.0.0.0",debug=True)